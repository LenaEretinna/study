﻿using System;
/*1. Написать программу «Анкета». Последовательно задаются вопросы 
 * (имя, фамилия, возраст, рост, вес). В результате вся информация 
 * выводится в одну строчку.
 * б) Используя форматированный вывод
 */
//Еретина
class Profile2
{
    static void Main()
    {
        Console.WriteLine("Введите  ваше имя");
        String name = Console.ReadLine();

        Console.WriteLine("Введите вашу фамилию");
        String surname = Console.ReadLine();

        Console.WriteLine("Введите ваш возраст");
        String age = Console.ReadLine();

        Console.WriteLine("Введите ваш рост");
        String height = Console.ReadLine();

        Console.WriteLine("Введите ваш вес");
        String weight = Console.ReadLine();

        Console.WriteLine("Запись в анкете: {1}  {0}. Возраст:  {2}. Рост: {3} см. Вес:  {4}  кг" , name, surname, age, height, weight);

        Console.ReadKey();
    }
}
