﻿using System;
/*5.
а) Написать программу, которая выводит на экран ваше имя, фамилию и город проживания.
 */
//Еретина
class Me
{
    static void Main()
    {
        Console.WriteLine("Лена Еретина, г.Москва");

        Console.ReadKey();
    }
}