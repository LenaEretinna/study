﻿using System;
// Еретина Лена 
namespace Lesson2
{
    class Program
    {
        static int Task1()
        // Написать метод, возвращающий минимальное из трех чисел.
        {
            int a = 100;
            int b = 80;
            int c = 50;
            int min;
            if (a < b && a < c)
            {
                min = a;
            }
            else if (b < a && b < c)
            {
                min = b;
            }
            else min = c;
            return min;
        }

        static void Task2()
        // написать метод подсчета количества цифр.
        {
            Console.WriteLine("Введите число");
            int number = int.Parse(Console.ReadLine());
            int count = 0;
            while (number != 0)
            {
                count++;
                number = number / 10;
            }
            Console.WriteLine(count);
        }

        static void Task3()
        /*С клавиатуры вводятся числа, пока не будет введен 0. 
        Подсчитать сумму всех нечетных положительных чисел */

        {
            int commonSum = 0, number;
            do
            {
                Console.WriteLine("Введите число");
                number = Int32.Parse(Console.ReadLine());
                if ((number > 0) && (number % 2 == 1)) commonSum += number;
            } while (number != 0);
            Console.WriteLine("сумма введеных нечетных чисел " + commonSum);

        }

        static void Task4_1()
        {

        string login = "root";
        string password = "GeekBrains";
        int mistake = 0;
          
            while (mistake < 3)
            {
                Console.WriteLine("Введите логин");
                string UserLogin = Console.ReadLine();
                Console.WriteLine("Введите пароль");
                string UserPassword = Console.ReadLine();
                if (UserLogin == login & UserPassword == password)
                {
                   
                    Console.WriteLine("Вход выполнен");
                    break;
                }
                else
                {
                    Console.WriteLine("неверный логин или пароль. Введите еще раз");
                    mistake++;
                      
                }
            }

        }
        //static void LP(string l, string p)
        //{
        //    Console.WriteLine("Введите логин");
        //    l= Console.ReadLine();
        //    Console.WriteLine("Введите пароль");
        //    p = Console.ReadLine();
        //}

      
        static bool Check(string a, string b)
            //метод проверки логина и пароля
        {
           bool entry;
           //int mistake = 0;

            if (a == "root" & b == "GeekBrains")
            {
                entry = true;
                Console.WriteLine("Вход выполнен");
                
            }
            else {
                entry = false;
                Console.WriteLine("Ошибка ввода. Введите заново");
            }
            return entry;
        }

        static void Task4()
            /* используя метод проверки (Check) логина и пароля программа
             * пропускает пользователя или нет.С помощью цикла do-while
             * ограничить ввод пароля тремя попытками
             */
        {
            int m = 3;

            do
            {

                Console.WriteLine("Введите логин");
                string UserLogin = Console.ReadLine();
                Console.WriteLine("Введите пароль");
                string UserPassword = Console.ReadLine();
                var CheckResult = Check(UserLogin, UserPassword);


                if (CheckResult != true) m--;
                else m = m - 4;



            } while (m > 0);
        }

        static int Menu()
            // список заданий
        {
            Console.WriteLine("1 - Метод, возвращающий минимальное из трех чисел");
            Console.WriteLine("2 - Метод подсчета количества цифр числа");
            Console.WriteLine("3 - Метод подсчета всех введенных с клавиатуры нечетных полождительных чисел. Ноль - стоп ввода");
            Console.WriteLine("4 - Используя метод проверки программа пропускает пользователя или нет, с ограничением в три попытки( do-while)");
            Console.WriteLine("5 - Еще один способ решения четвертого задания. (Случайно получился, жалко было удалять))");
            int choice = int.Parse(Console.ReadLine());
            return choice;
        }

        static void Main()
        {
            int m = Menu();

            switch(m)
            {
                case 1:
                    Console.WriteLine(Task1());

                    break;
                case 2:
                    Task2();
                    break;
                case 3:
                    Task3();
                    break;
                case 4:
                    Task4();
                    break;
                case 5:
                    Task4_1();
                    break;

            }
            
            

           




            Console.ReadKey();

        }
    }
}