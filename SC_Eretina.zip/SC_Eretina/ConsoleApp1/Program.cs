﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


// Еретина

namespace ConsoleApp1
{
    class Program
    {

        static public bool LoginCheck(string s)
        {
            if (s.Length < 2 || s.Length > 10) return false;
            if (Char.IsDigit(s[0])) return false;
            for (int i = 1; i < s.Length; i++)
                if (!(Char.IsLetterOrDigit(s[i]))) return false;
            return true;
        }
        //Создать программу, которая будет проверять корректность ввода логина. Корректным логином будет строка от 2 до 10 символов, содержащая только буквы латинского алфавита или цифры, при этом цифра не может быть первой:
        //  а) без использования регулярных выражений;
        static void Task1()
        {
            string login = Console.ReadLine();
            if (LoginCheck(login)) Console.WriteLine("проверка пройдена");
            else Console.WriteLine("проверка не пройдена");
        }



        static int Menu()
        // список заданий
        {
            Console.WriteLine("1 - Создать программу, которая будет проверять корректность ввода логина. \nКорректным логином будет строка от 2 до 10 символов, содержащая только буквы латинского алфавита или цифры, \nпри этом цифра не может быть первой:без использования регулярных выражений;");
            Console.WriteLine("2 - Разработать статический класс Message, содержащий следующие статические методы для обработки текста \n Вывести только те слова сообщения,  которые содержат не более n букв. \n Удалить из сообщения все слова, которые заканчиваются на заданный символ. \nНайти самое длинное слово сообщения \nСформировать строку с помощью StringBuilder из самых длинных слов сообщения.");
            int choice = int.Parse(Console.ReadLine());
            return choice;
        }

        static void Main(string[] args)
        {
            int m = Menu();

            switch (m)
            {
                case 1:
                    Task1();
                    break;
                case 2:
                    Message.Demo();
                    break;

            }
            Console.ReadKey();
        }
    }
    class Message
    /*Разработать статический класс Message, содержащий следующие статические методы для обработки текста:
    а) Вывести только те слова сообщения,  которые содержат не более n букв.
    б) Удалить из сообщения все слова, которые заканчиваются на заданный символ.
    в) Найти самое длинное слово сообщения.
    г) Сформировать строку с помощью StringBuilder из самых длинных слов сообщения.*/
    {
        //метод, позволяющий вывести только те слова сообщения,  которые содержат не более n букв

       public static void Lenght(string s, int len)
        {
            string[] ss = s.Split(' ');
            foreach (string item in ss)
                if (item.Length == len) Console.WriteLine(item);
        }

        //метод, позволяющий удалить из сообщения все слова, которые заканчиваются на заданный символ
        public static string DeleteWord(string s, char c)
        {
            string[] ss = s.Split(' ');
            string newStr = "";
            foreach (string item in ss)
                if (item[item.Length - 1] != 'c') newStr += item + ' ';
            return newStr;
        }

        //метод, находящий самое длинное слово сообщения
        public static int WordMax(string s)
        {
            string[] ss = s.Split(' ');
            int max = -1;
            foreach (var item in ss)
                if (item.Length > max) max = item.Length;
            return max;
        }

        public static void StringWithMax(string s)
        {
            string[] ss = s.Split(' ');
            int max = WordMax(s);
            StringBuilder sb = new StringBuilder();
            foreach (string item in ss)
                if (item.Length == max)
                {
                    //sb.Append(item);
                    Console.WriteLine(sb.Append(item));
                }

        }

        public static void Demo()
        {
            string s = "Я пришел к тебе с приветом, рассказать, что солнце встало, что оно горячим светом по листам затрепетало";
            Console.WriteLine(s);
            Console.WriteLine("все слова определенной длины");
            Lenght(s, 6);
            Console.WriteLine("удалены слова, заканчивающиеся на заданный символ");
            DeleteWord(s, 'м');
            Console.WriteLine("самое длинное слово");
            WordMax(s);
            Console.WriteLine("строка из самых длинных слов cформированная с помощью StringBuilder");
            StringWithMax(s);
        }
    }
}

