﻿using System;
using System.IO;

//Еретина

// смогла сделать только одно задание, чтобы оно все же работало


namespace Lesson4
{
    class Lesson4
    {
        static void Massive()
        /* 1. Дан  целочисленный  массив  из 20 элементов.  
         * Элементы  массива  могут принимать  целые  значения  от –10 000 до 10 000 включительно. 
         * Заполнить случайными числами.  Написать программу, позволяющую найти и вывести количество 
         * пар элементов массива, в которых только одно число делится на 3. В данной задаче под парой 
         * подразумевается два подряд идущих элемента массива. 
         */
        {
            Random rnd = new Random();
            int[] a = new int[20];
            for (int i = 0; i < a.Length; i++)
            {
                a[i] = rnd.Next(-10000, 10001);
                Console.WriteLine(a[i] + " ");
            }

            int count = 0;
            for (int i = 0; i < a.Length - 1; i++)
                if (a[i] % 3 == 0 || a[i + 1] % 3 == 0) count++;
            Console.WriteLine("\n" + count);

        }



        static void Main()
        {

            Massive();

            Console.ReadKey();
        }
    }

    class MyArray
    {
        /* 3 а) Дописать класс для работы с одномерным массивом. 
         * Реализовать конструктор, создающий массив определенного размера и 
         * заполняющий массив числами от начального значения с заданным шагом. 
         * Создать свойство Sum, которое возвращает сумму элементов массива, 
         * метод Inverse, возвращающий новый массив с измененными знаками у всех элементов массива (старый массив, остается без изменений),  
         * метод Multi, умножающий каждый элемент массива на определённое число, 
         * свойство MaxCount, возвращающее количество максимальных элементов. 
         */

        private int [] a;
        //конструктор для создания массива размера n и заполнения его одним значением е1 
        public MyArray(int n, int e1)
        {
            a = new int[n];
            for (int i = 0; i < n; i++) a[i] = e1;   
        }

        // кконструктор, заполняющий массив числами от начального значения с заданным шагом
        public MyArray(int n, int first, int last)
        {
            a = new int[n];
            Random rnd = new Random();
            for (int i = 0; i < n; i++) a[i] = rnd.Next(first, last + 1);

        }
        //свойство Sum, которое возвращает сумму элементов массива
        public int Sum
        {
            get
            {
                int sum = 0;
                foreach (int e1 in a) sum += e1;
                return sum;
            }
        }

        //метод Inverse, возвращающий новый массив с измененными знаками у всех элементов массива
        public void Inverse()
        {
            for (int i = 0; i < a.Length; i++) a[i] = -a[i];
        }

        //метод Multi, умножающий каждый элемент массива на определённое число
        public void Multi(int n)
        {
            
            for (int i = 0; i < a.Length; i++) a[i] = n * a[i];
            
        }

        //войство MaxCount, возвращающее количество максимальных элементов
         public int MaxCount
        {
            get
            {
                int max = this.MaxCount;
                int count = 0;
                foreach (int e1 in a) if (e1 == max) count++;
                return count;
            }
        }


       //// static void Main()
       // {
       //     MyArray a = new MyArray(3, 100,  345);
       //     Console.WriteLine(a);
           
       //     Console.WriteLine(a.Sum);
       //     a.Inverse();
       //     a.Multi(4);

            


       //     Console.ReadKey();

        //}
    }
}


