﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

//Еретина

namespace Lesson6
{
    //1. Изменить программу вывода функции так, чтобы можно было передавать функции типа double (double,double). 
    //Продемонстрировать работу на функции с функцией a*x^2 и функцией a*sin(x).

    public delegate double Fun(double x);
    public delegate double Func(double x, double a);

    class Program
    {
        public static void Table(Fun F, double x,double b)
        {
            Console.WriteLine("----- X ----- Y -----");
            while (x <= b)
            {
                Console.WriteLine("| {0,8:0.000} | {1,8:0.000} |", x, F(x));
                x += 1;
            }
        }

        public static void Table2(Func F,double x, double b,double a)
        {
            Console.WriteLine("----- X ----- A ----- Y -----");
            while (x <= b)
            {
                Console.WriteLine("| {0,8:0.000} | {1,8:0.000} | {2,8:0.000}", x, a, F(x, a));
                x += 1;
            }

        }

        public static double MyFunc(double x)
        {
            return x * x * x;
        }

        public static double MyFunc2( double x, double a)
        {
            return a * Math.Pow(x, 2);
        }

        public static double MyFunc3(double x, double a)
        {
            return a * Math.Sin(x);
        }

        public static void Demo()
        {
            Console.WriteLine("Таблица функции MyFunc:");
            Table(new Fun(MyFunc), -2, 2);
            Console.WriteLine("Таблица функции Sin:");
            Table(Math.Sin, -2, 2);
            Console.WriteLine("Таблица функции a*x^2:");
            Table2(MyFunc2, -2, 2, 3);
            Console.WriteLine("Таблица функции a*sin(x):");
            Table2(MyFunc3, -2, 2, 3);
        }
       
    }

     
}


namespace Delegat_Min_Func
{
    //2.  Модифицировать программу нахождения минимума функции так, чтобы можно было передавать функцию в виде делегата.
    public delegate double Fun(double x);
    class Programm
    {
        public static double F1(double x)
        {
            return x * x - 50 * x + 10;
        }

        public static double F2(double x)
        {
            return x * Math.Pow(x, 3);
        }

        public static double F3(double x)
        {
            return 25 - x;
        }
        public static void SaveFunc(string fileName, double a, double b ,double h, Fun F)
        {
            FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.Write);
            BinaryWriter bw = new BinaryWriter(fs);
            double x = a;
            while (x <= b)
            {
                bw.Write(F(x));
                x += h;
            }
            bw.Close();
            fs.Close();
        }

        public static double Load(string fileName)
        {
            FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            BinaryReader bw = new BinaryReader(fs);
            double min = double.MaxValue;
            double d;
            for( int i =0; i < fs.Length/sizeof(double); i++)
            {
                d = bw.ReadDouble();
                if (d < min) min = d;
            }
            bw.Close();
            fs.Close();
            return min;
        }
        static void Menu()
        {
            Console.WriteLine("Минимум из представленных функций");
            Console.WriteLine("1. x * x - 50 * x + 10");
            Console.WriteLine("2. x * Math.Pow(x, 3)");
            Console.WriteLine("3. 25 - x");
        }
         
        public static void Demo()
        {
            int choose = 0;
            bool flag;
            do
            {
                try
                {
                    flag = false;
                    Console.WriteLine("Выберите функцию");
                    choose = Convert.ToInt32(Console.ReadLine());
                    if (choose != 1 && choose != 2 && choose != 3)
                    {
                        Console.WriteLine("Введите только 1, 2 или 3");
                        flag = true;
                    }
                }
                catch (FormatException ex)
                {
                    Console.WriteLine("Неправильное значение");
                    Console.WriteLine(ex.Message);
                    flag = true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("НЕправильное значение");
                    Console.WriteLine(ex.Message);
                    flag = true;
                }
            } while (flag);
            Console.WriteLine("Введите число начала отрезка");
            double begin = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите число окончания отрезка");
            double end = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите шаг");
            double step = Convert.ToInt32(Console.ReadLine());
            Fun[] funmassiv = new Fun[] { F1, F2, F3 };
            SaveFunc("data.bin", begin, end, step, funmassiv[choose - 1]);
            Console.WriteLine(Load("data.bin"));

        }
        
    }
}

namespace Demo
{
    class DemoLesson
    {
        static int Menu()
        // список заданий
        {
            Console.WriteLine("1 - Изменить программу вывода функции так, чтобы можно было передавать функции типа double (double,double).");
            Console.WriteLine("2 - Модифицировать программу нахождения минимума функции так, чтобы можно было передавать функцию в виде делегата.");
            int choice = int.Parse(Console.ReadLine());
            return choice;
        }

        static void Main(string[] args)
        {
            int m = Menu();

            switch (m)
            {
                case 1:
                    Lesson6.Program.Demo();
                    break;
                case 2:
                    Delegat_Min_Func.Programm.Demo();
                    break;

            }
            Console.ReadKey();
        }
    }
}