﻿using System;
/*4. Написать программу обмена значениями двух переменных.
а) с использованием третьей переменной;
 */
//Еретина
class Swap
{
    
        static void Main()
    {
        int a, b, x;
        a = 67;
        b = 98;

         x = a;
         a = b;
         b = x;

        
   
        Console.WriteLine("a={0} and b ={1}", a, b);

        Console.ReadKey(); 
    }
}

