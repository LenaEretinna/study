﻿using System;
/*1. Написать программу «Анкета». Последовательно задаются вопросы 
 * (имя, фамилия, возраст, рост, вес). В результате вся информация 
 * выводится в одну строчку.
 * в) Используя вывод со знаком $
 */
//Еретина
class Profile3
{
    static void Main()
    {
        Console.WriteLine("Введите  ваше имя");
        String name = Console.ReadLine();

        Console.WriteLine("Введите вашу фамилию");
        String surname = Console.ReadLine();

        Console.WriteLine("Введите ваш возраст");
        String age = Console.ReadLine();

        Console.WriteLine("Введите ваш рост");
        String height = Console.ReadLine();

        Console.WriteLine("Введите ваш вес");
        String weight = Console.ReadLine();

        Console.WriteLine($"Запись в анкете: {surname}  {name}. Возраст:  {age}. Рост: {height} см. Вес:  {weight}  кг.");

        Console.ReadKey();
    }
}