﻿using System;
/*Ввести вес и рост человека. Рассчитать и вывести индекс массы тела (ИМТ) по формуле I=m/(h*h); 
 * где m — масса тела в килограммах, h — рост в метрах
 */
//Еретина
class Index
{
    static void Main()
    {
        Console.WriteLine("Введите ваш вес (в кг)");
        var weight = Int32.Parse(Console.ReadLine());

        Console.WriteLine("Введите ваш рост (в м)");
        var height = float.Parse(Console.ReadLine());


        Console.WriteLine("Индекс массы вашего тела = " + weight/(height*height) );

        Console.ReadKey();
    }
}
   