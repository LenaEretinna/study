﻿using System;
/*5. Написать программу, которая выводит на экран ваше имя, фамилию и город проживания.
в) *Сделать задание б с использованием собственных методов (например, Print(string ms, int x,int y)
 */
//Еретина
class Me
{
    static void Print(string ms)
    {
        Console.SetWindowSize(100, 11);
        Console.SetCursorPosition(39, 5);
        Console.WriteLine(ms);

        
    }
    static void Main()
    {
       

        Print("Лена Еретина, г.Москва");
        Console.ReadKey();


    }
}