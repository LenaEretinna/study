﻿using System;
/*5. Написать программу, которая выводит на экран ваше имя, фамилию и город проживания.
б) Сделать задание, только вывод организуйте в центре экрана
 */
//Еретина
class Me
{
    static void Main()
    {
        Console.SetWindowSize(100, 11);
        Console.SetCursorPosition(39, 5);
        Console.WriteLine("Лена Еретина, г.Москва");

        Console.ReadKey();
    }
}