﻿using System;
//Еретина

//1.a и б дописать структуру Complex,добавив метод вычитания комплексных чисел
// добавить метод вычитания и деления чисел. проверить работу класса
struct Complex
{
    public double im;
    public double re;

    // сложение

    public Complex Add(Complex x)
    {
        Complex y;
        y.im = im + x.im;
        y.re = re + x.re;
        return y;
    }

    // произведение
    public Complex Multy (Complex x)
    {
        Complex y;
        y.re = re * x.re - im * x.im;
        y.im = re * x.im + im * x.re;
        return y;
    }

    // деление
    public Complex Div (Complex x)
    {
        Complex y;
        y.re = (re * x.re + im * x.im) / (x.im * x.im + x.re * x.re);
        y.im = (im * x.re - re * x.im) / (x.im * x.im + x.re * x.re);
        return y;
    }

    // вычитание
    public Complex Sub(Complex x)
    {
        Complex y;
        y.re = re - x.re;
        y.im = im - x.im;
        return y;
    }

    // перегрузка метода 
    public override string ToString()
    {
        return re + "+" + im + "i";
    }

    public static void Demo()
    {
        Complex complex1;
        complex1.re = 3;
        complex1.im = 2;
        Complex complex2;
        complex2.re = 4;
        complex2.im = 6;

        Console.WriteLine("Number 1: " + complex1.ToString());
        Console.WriteLine("Number 2: " + complex2.ToString());

        Complex resultAdd = complex1.Add(complex2);
        Complex resultMulty = complex1.Multy(complex2);
        Complex resultDivide = complex1.Div(complex2);
        Complex resultSub = complex1.Sub(complex2);

        Console.WriteLine("Add: " + resultAdd.ToString());
        Console.WriteLine("Multy: " + resultMulty.ToString());
        Console.WriteLine("Divide: " + resultDivide.ToString());
        Console.WriteLine("Sub: " + resultSub.ToString());
    }

}

// описать класс дробей, предусмотреть  методы сложения, вычитания, умножения, деления.
//продемнстрировать работу   
class Fraction
{
   
    public int Numerator { get; set;}
    public int Denominator { get; set;}

    public Fraction() : this(1, 1) { }

    public Fraction(int numerator, int denomirator)
    {
        this.Numerator = numerator;
        if (denomirator == 0) throw new ArgumentException("Знаменатель не может быть равен 0");
        else this.Denominator = denomirator;
    }

    public Fraction(Fraction fract) : this(fract.Numerator, fract.Denominator) { }

    // сложение
    public static Fraction Addition(Fraction a, Fraction b)
    {
        Fraction result = new Fraction();

        result.Numerator = a.Numerator * b.Denominator + b.Numerator * a.Denominator;
        result.Denominator = a.Denominator * b.Denominator;

        int nod = NOD(result.Numerator, result.Denominator);
        result.Numerator /= nod;
        result.Denominator /= nod;
        return result;
    }
     
    // вычитание
    public static Fraction Subtraction( Fraction a, Fraction b)
    {
        Fraction result = new Fraction();

        result.Numerator = a.Numerator * b.Denominator - b.Numerator * a.Denominator;
        result.Denominator = a.Denominator * b.Denominator;

        int nod = NOD(result.Numerator, result.Denominator);
        result.Numerator /= nod;
        result.Denominator /= nod;
        return result;
    }
    
    // умножение
    public static Fraction Multiplication (Fraction a, Fraction b)
    {
        Fraction result = new Fraction();

        result.Numerator = a.Numerator * b.Numerator;
        result.Denominator = a.Denominator * b.Denominator;

        int nod = NOD(result.Numerator, result.Denominator);
        result.Numerator /= nod;
        result.Denominator /= nod;
        return result;
    }

    // деление
    public static Fraction Division(Fraction a, Fraction b)
    {
        Fraction result = new Fraction();

        result.Numerator = a.Numerator * b.Denominator;
        result.Denominator = a.Denominator * b.Numerator;

        int nod = NOD(result.Numerator, result.Denominator);
        result.Numerator /= nod;
        result.Denominator /= nod;
        return result;
    }

    // наибольший общий делитель
    static int NOD (int a, int b)

    {
        while (a!=0 && b != 0)
        {
            if (a > b) a = a % b;
            else b = b % a;
        }
        return a + b;

    }

    public override string ToString()
    {
        return string.Format($"{this.Numerator}/{this.Denominator} ({(double)this.Numerator/ this.Denominator:F2})");
    }
    public static void Demo()
    {
        Fraction a = new Fraction(1, 2);
        Fraction b = new Fraction(1, 2);

        Fraction add = Fraction.Addition(a, b);
        Fraction sub = Fraction.Subtraction(a, b);
        Fraction multy = Fraction.Multiplication(a, b);
        Fraction divide = Fraction.Division(a, b);

        Console.WriteLine("Сложение: " + add);
        Console.WriteLine("Вычитание: " + sub);
        Console.WriteLine("Умножение: " + multy);
        Console.WriteLine("Деление: " + divide);
    }
}

class programm
{

      static int Menu()
      {
        Console.WriteLine("1 - Структура Complex. \nДописать структуру, добавив метод вычитания \nи деления чисел. проверить работу класса");
        Console.WriteLine("2 - Класс Fraction. \nОписать класс дробей, предусмотреть  методы \nсложения, вычитания, умножения, деления. \nИ продемонстрировать работу");
        int choice = int.Parse(Console.ReadLine());
        return choice;
      }

   static void Main()
   {
       int m = Menu();

         switch (m)
         {
              case 1:
                Complex.Demo();
                break;
              case 2:
                Fraction.Demo();
                break;
         }
        Console.ReadKey();
   }
}
