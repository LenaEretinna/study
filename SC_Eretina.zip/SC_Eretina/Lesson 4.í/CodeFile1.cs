﻿using System;
/*4. Написать программу обмена значениями двух переменных.
b) без использования третьей переменной;
 */
//Еретина
class Swap2
{
  
    static void Main()
    {
        int a, b ;
        a = 67;
        b = 98;

       // обмен значениями
        a = a + b;
        b = a - b;
        a = a - b;
    
        Console.WriteLine("a={0} and b ={1}", a, b);

        Console.ReadKey();
    }
}