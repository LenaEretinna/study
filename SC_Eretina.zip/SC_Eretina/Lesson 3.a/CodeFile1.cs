﻿using System;
/* 3 а) Написать программу, которая подсчитывает расстояние между точками с координатами x1, y1 и x2,y2 
 * по формуле r=Math.Sqrt(Math.Pow(x2-x1,2)+Math.Pow(y2-y1,2). 
 * Вывести результат, используя спецификатор формата .2f (с двумя знаками после запятой);
 */
//Еретина
class Distance
{
    static void Main()
    {
        int x1, x2, y1, y2; 
          double distance;
        x1 = 45;
        x2 = 476;
        y1 = 78;
        y2 = 657;
        distance = Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));

        Console.WriteLine("Расстояние: {0:f2}", distance);

        Console.ReadKey();
    }
}