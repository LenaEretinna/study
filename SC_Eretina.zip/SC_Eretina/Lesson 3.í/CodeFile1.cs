﻿using System;
/* 3 b) Написать программу, которая подсчитывает расстояние между точками с координатами x1, y1 и x2,y2 
 * по формуле r=Math.Sqrt(Math.Pow(x2-x1,2)+Math.Pow(y2-y1,2). 
 * Вывести результат, используя спецификатор формата .2f (с двумя знаками после запятой)
 * оформив вычисления расстояния между точками в виде метода;
 */
//Еретина
class Distance
{
    static void FindDistance(int x1, int x2, int y1, int y2)
    {
        
        double distance = Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));
        Console.WriteLine("Расстояние: {0:f2}", distance);
    }
    static void Main()
    {
        int a1, a2, b1, b2;
        
        a1 = 45;
        a2 = 476;
        b1 = 78;
        b2 = 657;
        
        FindDistance( a1, a2, b1, b2);

        Console.ReadKey();
    }
}